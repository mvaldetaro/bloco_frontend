import angular from 'angular';
import appModule from './mock/app.mock';

angular.bootstrap(document.body, [appModule]);
