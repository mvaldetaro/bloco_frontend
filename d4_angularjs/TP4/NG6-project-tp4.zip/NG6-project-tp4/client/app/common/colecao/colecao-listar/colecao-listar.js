import angular from 'angular';
import colecaoListarComponent from './colecao-listar.component';

let colecaoListarModule = angular.module('colecaoListar', [

])

.component('colecaoListar', colecaoListarComponent)

.name;

export default colecaoListarModule;
