import angular from 'angular';
import itemDetailComponent from './item-detalhar.component';

let itemDetailModule = angular.module('itemDetalhar', [

])

.component('itemDetalhar', itemDetailComponent)

.name;

export default itemDetailModule;
