import angular from 'angular';
import itemEditarComponent from './item-editar.component';

let itemEditarModule = angular.module('itemEditar', [

])

.component('itemEditar', itemEditarComponent)

.name;

export default itemEditarModule;
