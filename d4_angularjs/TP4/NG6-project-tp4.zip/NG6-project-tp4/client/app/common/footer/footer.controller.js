class FooterController {
  constructor() {
    
  }
}

export default FooterController;
