class AboutController {
  constructor() {
    this.titulo = 'About';
  }
}

export default AboutController;
