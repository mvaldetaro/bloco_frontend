import template from './usuarios.html';
import controller from './usuarios.controller';
//import './usuarios.scss';

let usuariosComponent = {
  bindings: {},
  template,
  controller
};

export default usuariosComponent;
