let data = [{ //esses contacts estão mockados direto no serviço, não usam o angular-mocks ainda
  "id":1,
  "nome": "Mcneil Payne",
  "fone": "+55 (832) 409-2318"
}, {
  "id":2,
  "nome": "Mitzi Patterson",
  "fone": "+55 (820) 413-2975"
}, {
  "id":3,
  "nome": "Blair Jordan",
  "fone": "+55 (944) 483-3534"
}, {
  "id":4,
  "nome": "Walton Fulton",
  "fone": "+55 (986) 582-2748"
}, {
  "id":5,
  "nome": "Black Evans",
  "fone": "+55 (886) 492-3379"
}, {
  "id":6,
  "nome": "Hurst Banks",
  "fone": "+55 (843) 558-3725"
}];

export default data;
