let data = [{
  "id": 1,
  "nome": 'Tony Stark',
  "login": 'iron',
  "senha": 123,
  "fone": "(11) 91111-1111"
}, {
  "id": 2,
  "nome": 'Jarvis',
  "login": 'jarvis',
  "senha": 123,
  "fone": "(22) 92222 2222"
}];

export default data;
